	<h1 class="h3 mb-3">Profile</h1>

					<div class="row">
						<div class="col-md-4 col-xl-3">
							<div class="card mb-3">
								<div class="card-header">
									<h5 class="card-title mb-0"></h5>
								</div>
								<div class="card-body text-center">
									
									<?php
									if(empty($photo[$id])){
										echo '<img src="userphoto/avatar.jpg" alt="Christina Mason" class="img-fluid rounded-circle mb-2" width="128" height="128" />';
									}else{
										?>
										<img src="userphoto/<?php echo $photo[$id]; ?>" alt="Christina Mason" class="img-fluid rounded-circle mb-2" width="128" height="128" />
										<?php
									}
									
									?>
									
									
									
									
									<h5 class="card-title mb-0"><?php echo $fullname[$id]; ?></h5>
									<div class="text-muted mb-2"><?php echo htmlspecialchars($mobile[$id]); ?></div>


									
			
									<div>
										
										
									<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-edit-user">
										Edit
									</button>
									<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-photo-user">
										Upload Photo
									</button>


									<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-reset-password">
										Reset Password
									</button>
										
										
										<a class="btn btn-primary btn-sm" href="#">Diactive</a>
										
									</div>
								</div>
								
						<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">About</h5>
									<ul class="list-unstyled mb-0">
										
										<li class="mb-1"><span data-feather="briefcase" class="feather-sm me-1"></span> Works at <a href="#"></a></li>
										
									</ul>
								</div>								
								
								
								
								
								<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">User Access to:</h5>
									<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-user-access">
										+
									</button>
									
									<?php
									 foreach ($permision_ as $key => $permision) {
									 	?>
										 <span class="badge bg-primary"><?php echo $permision; ?></span> 
										 <?php
									 }
									
									?>
									
									
									<button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-user-remove">
										-
									</button>
									
									
									
									
								</div>
								
								
								
								
								
								
								<!--
								<hr class="my-0" />
								<div class="card-body">
									<h5 class="h6 card-title">Elsewhere</h5>
									<ul class="list-unstyled mb-0">
										<li class="mb-1"><span class="fas fa-globe fa-fw me-1"></span> <a href="#">staciehall.co</a></li>
										<li class="mb-1"><span class="fab fa-twitter fa-fw me-1"></span> <a href="#">Twitter</a></li>
										<li class="mb-1"><span class="fab fa-facebook fa-fw me-1"></span> <a href="#">Facebook</a></li>
										<li class="mb-1"><span class="fab fa-instagram fa-fw me-1"></span> <a href="#">Instagram</a></li>
										<li class="mb-1"><span class="fab fa-linkedin fa-fw me-1"></span> <a href="#">LinkedIn</a></li>
									</ul>
								</div>
							-->
								
								
							</div>
						</div>

						<div class="col-md-8 col-xl-9">
							<div class="card">
								<div class="card-header">

									<h5 class="card-title mb-0">Activities</h5>
								</div>
								<div class="card-body h-100">

									
									
								
									
								
								

									
								
								</div>
							</div>
						</div>
					</div>
