
				<h1 class="h3 mb-3">New User</h1>		
				
				
					<div class="row">
						<div class="col-12 col-xl-6">
							<div class="card">
								<div class="card-header">
									
								</div>
								<div class="card-body">
									<form method="post" action="app/bm_users/post_newuser.php">
										<div class="mb-3">
											<label class="form-label">Full Name</label>
											<input type="text" name="fullname"  class="form-control"   placeholder="Full Name" required="" >
										</div>
										<div class="mb-3">
											<label class="form-label">Mobile</label>
											<input type="text"  name="mobile" class="form-control" placeholder="Mobile Number" required="" >
										</div>
												
										<div class="mb-3">
											<label class="form-check m-0">
												<input type="checkbox" class="form-check-input">
												<span class="form-check-label">Mark as Active</span>
											</label>
										</div>
										<button type="submit" class="btn btn-primary">Submit</button>
									</form>
								</div>
							</div>
						</div>
						
						
					


			
					</div>
