
						<div class="col-12 col-xl-4">
							<div class="card">
								<div class="card-header">
									Recent Registration
								</div>
								<div class="card-body">
									
										
										
										
										
										

																		
										
										
									
								</div>
							</div>
			
</div>