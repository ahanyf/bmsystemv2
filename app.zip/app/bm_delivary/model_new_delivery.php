
<!-- BEGIN  modal -->
									<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#m-new-delivery">
										Small
									</button>
									
				<!-- 555	-->				
									
									<div class="modal fade" id="m-new-delivery" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog " role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Edit User </h5>
													
													<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
												</div>
												<div class="modal-body m-3">
													
											<!-- -------------------------------------------- -->
												
							<div class="tab">
								<ul class="nav nav-tabs" role="tablist">
									<li class="nav-item"><a class="nav-link active" href="#tab-1" data-bs-toggle="tab" role="tab">Home</a></li>
									<li class="nav-item"><a class="nav-link" href="#tab-2" data-bs-toggle="tab" role="tab">Profile</a></li>
									<li class="nav-item"><a class="nav-link" href="#tab-3" data-bs-toggle="tab" role="tab">Messages</a></li>
								</ul>
							
								<div class="tab-content">
								
									<div class="tab-pane active" id="tab-1" role="tabpanel">
										<h4 class="tab-title">Default tabs</h4>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor tellus eget condimentum
											rhoncus. Aenean massa. Cum sociis natoque penatibus et magnis neque dis parturient montes, nascetur ridiculus mus.
										</p>
										<p>Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede
											justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
											justo.</p>
									</div>
									<div class="tab-pane" id="tab-2" role="tabpanel">
										<h4 class="tab-title">Another one</h4>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor tellus eget condimentum
											rhoncus. Aenean massa. Cum sociis natoque penatibus et magnis neque dis parturient montes, nascetur ridiculus mus.
										</p>
										<p>Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede
											justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
											justo.</p>
									</div>
									<div class="tab-pane" id="tab-3" role="tabpanel">
										<h4 class="tab-title">One more</h4>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor tellus eget condimentum
											rhoncus. Aenean massa. Cum sociis natoque penatibus et magnis neque dis parturient montes, nascetur ridiculus mus.
										</p>
										<p>Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede
											justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae,
											justo.</p>
									</div>
								</div>
							
											
								</div>			
											
											<!--////////////////////////////////////////////////////////////////////// -->

												</div>
												<div class="modal-footer">
												<button type="submit" class="btn btn-primary">Submit</button>
												</form>
												
												</div>
											</div>
										</div>
									</div>
									<!-- END  modal -->
									