
	
	
	
	
	<div class="progress">
										<div class="progress-bar" role="progressbar" style="width: 10%" aria-valuenow="25" aria-valuemin="0"
											aria-valuemax="100">Delivary Set</div>
										<div class="progress-bar bg-warning" role="progressbar" style="width: 15%" aria-valuenow="15" aria-valuemin="0"
											aria-valuemax="100">Waiting Time</div>
										<div class="progress-bar bg-success" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0"
											aria-valuemax="100">Started</div>
										<div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0"
											aria-valuemax="100">Fully Delivered</div>
									</div>	