

					<div class="row">
						<div class="col-12">
						<div class="card">
						<!---
						
							
								 <div class="card-header">
      							 
      							  
      							
      							 

     							 </div>
								
								
									
													

							
							m-location-edit<?php echo $id; ?>
						-->
							
							
					<div class="card-body">
					
								
									
									
								<div class="tab">
									
									  <h2> <?php echo  $location_name[$location_id]; ?></h2>
      							  
      							  <?php echo $location_notes[$location_id]; ?> | 
      							  <?php echo  $location_type[$location_id];   ?> |
      							  <?php echo  $location_island[$location_id]; ?> 
									
									
									<button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#m-location-edit<?php echo $location_id; ?>"  >Edit</button>
									<button class="btn btn-primary btn-sm">Upload Photo</button>
									<button class="btn btn-primary btn-sm">Location Link</button>
									
									<button class="btn btn-primary btn-sm">New GAS Cylinder Delivery</button>
									<button class="btn btn-primary btn-sm">New Delivery</button>
									
									<hr>
									
								<ul class="nav nav-tabs" role="tablist">
									<li class="nav-item"><a class="nav-link active" href="#tab-1" data-bs-toggle="tab" role="tab">Home</a></li>
									<li class="nav-item"><a class="nav-link" href="#tab-2" data-bs-toggle="tab" role="tab">Profile</a></li>
									<li class="nav-item"><a class="nav-link" href="#tab-3" data-bs-toggle="tab" role="tab">Messages</a></li>
								</ul>
								
								
								<div class="tab-content">
								
									<div class="tab-pane active" id="tab-1" role="tabpanel">
										<h4 class="tab-title">Default tabs</h4>
										<p>Lorem ipsum dolor sit amet, cono, rhoncus ut, imperdiet a, venenatis vitae,
											justo.</p>
									</div>
									
									<div class="tab-pane" id="tab-2" role="tabpanel">
										<h4 class="tab-title">Another one</h4>
										<p>Lorem ipsum dolortae,
											justo.</p>
									</div>
									
									<div class="tab-pane" id="tab-3" role="tabpanel">
										<h4 class="tab-title">One more</h4>
										<p>Lo</p>
									</div>
								</div>
							
							
							</div>
						
									
									
									
									
								</div>	
									
						</div>			
									
									
				
						</div>
					</div>
												
									
									
									
									
									
									
									
					